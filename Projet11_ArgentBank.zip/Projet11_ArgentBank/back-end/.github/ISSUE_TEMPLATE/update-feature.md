---
name: '#5 Update Profile Feature'
about: Issue for the profile update requirement
title: User can update their profile
labels: ''
assignees: ''
---

A user should be able to:

- [ ] Edit their profile (first name and last name not editable. Only username can be changed). - [ ] This data should be persisted to the database.

For more information on accessing the design assets, see the [Design Assets section in the README](https://github.com/OpenClassrooms-Student-Center/ArgentBank-website#design-assets).
